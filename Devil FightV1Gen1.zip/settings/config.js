const fs = require('fs')

const config = {
    owner: "6283832320022", //GANTI NOMER KALIAN AGAR BISA AKSES BOT
    botNumber: "6283832320022", //GANTI NOMER KALIAN AGAR BISA AKSES BOT
    thumbUrl: "https://files.catbox.moe/pfttxc.jpg",
    session: "sessions",
    status: {
        public: true, //UBAH KE false JIKA INGIN BOT KALIAN KE MODE self
        terminal: true, //JANGAN DI UBAH, JIKA UBAH KE false MAKA AKAN MENGGUNAKAN QR CODE
        reactsw: false, //BEBAS UBAH KE true, AGAR AUTO REACT SW
    },
    message: {
        owner: "*｢ 𝐀𝐂𝐂𝐄𝐒 𝐃𝐄𝐍𝐈𝐄𝐃 ｣*",
        group: "Ketiknya Didalam Group Yang Mau Di Bug Bego.",
        admin: "*｢ 𝐀𝐂𝐂𝐄𝐒 𝐃𝐄𝐍𝐈𝐄𝐃 ｣*",
        private: "this is specifically for private chat"
    },
    settings: {
        title: "🩸 —͟͞Devil Fight",
        packname: 'Devil Gread',
        description: "This Script Was Created By VinzzOfficial",
        author: 'Vinzz Develonger',
        footer: "YouTube 🩸 —͟͞Devil Fight"
    },
    newsletter: {
        name: "Information Devil Fight",
        id: "120363407849633830@newsletter"
    },
    socialMedia: {
        YouTube: "https://youtube.com/@devil.fight.crasher",
        GitHub: "https://github.com/DevilFight",
        Telegram: "https://t.me/DevilGread",
        ChannelWA: "https://whatsapp.com/channel/0029VbCh96Q30LKMgX7myV0P"    
    }
}

module.exports = config;

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
